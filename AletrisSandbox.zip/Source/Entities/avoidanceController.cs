using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using Monocle;
using NLua;

namespace Celeste.Mod.AletrisSandbox.Entities;

[CustomEntity("AletrisSandbox/avoidanceController")]
public class AvoidanceController : Entity
{

    public string luaData;

    Vector2 stupidStoredOffset;

    public Entity[] followingPlayer;
    public Lua lua;
    public float timer;

    public AvoidanceController(EntityData data, Vector2 offset)
        : base(data.Position + offset) // conversion from room to world position
    {

        luaData = data.String("luaData", "");

        stupidStoredOffset = offset;
        lua = new Lua();
    }

    [Tracked]
    public class ACMovement() : Component(true, false)
    {
        public int? followPlayerSpd { get; set; }

        public int Lifetime;
        public Vector2 velocity;
        public int timer;
        public bool rebound;

        public ACMovement(Vector2 vel, int lifetime, int? followPlayerSpd, bool reboun) : this()
        {
            Lifetime = (lifetime > 0) ? lifetime : -1;
            this.followPlayerSpd = followPlayerSpd;
            velocity = vel;
            timer = 0;
            rebound = reboun;
        }

        public override void Update()
        {
            Entity.Position.X += velocity.X;
            if (rebound)
            {
                if (Entity.CollideCheck<Solid>()) { velocity.Y = -velocity.Y; }
            }

            Entity.Position.Y += velocity.Y;
            if (rebound)
            {
                if (Entity.CollideCheck<Solid>()) { velocity.Y = -velocity.Y; }
            }

            Player plr = SceneAs<Level>().Tracker.GetEntity<Player>();
            if (plr != null && followPlayerSpd != null && followPlayerSpd != 0) // this is fucking stupid omg
            {
                Vector2 dir = Entity.Position - plr.Position;
                velocity = (Vector2)(-dir / dir.Length() * followPlayerSpd);
            }

            if (Lifetime < 0) { return; }
            if (timer < Lifetime)
            { timer++; }
            else
            {
                Entity.RemoveSelf();
            }
            base.Update();
        }
    }


    #region HelperFunctions

    public void SpawnObj(string sid , LuaTable position, LuaTable velocity, int lifeTimer, bool rebound, int followPlayerSpd, LuaTable param) // pos,vel = { x = 0, y = 0 }. param = dictionary
    {
        Level scene = SceneAs<Level>();

        Vector2 convertedPos;
        Vector2 convertedVel;
        Dictionary<string, object> convertedParams = new();

        float px = 0f, py = 0f;

        if (position != null)
        {
            px = Convert.ToSingle(position["x"] ?? 0);
            py = Convert.ToSingle(position["y"] ?? 0);
        }
        convertedPos = new Vector2(px, py);

        float vx = 0f, vy = 0f;

        if (velocity != null)
        {
            vx = Convert.ToSingle(velocity["x"] ?? 0);
            vy = Convert.ToSingle(velocity["y"] ?? 0);
        }
        convertedVel = new Vector2(vx, vy);

        if (param != null)
        {
            foreach (var key in param.Keys)
            {
                convertedParams[key.ToString() ?? throw new InvalidOperationException()] = param[key];
            }
        }

        /*foreach (var h in Level.EntityLoaders)
        {
            Logger.Log(LogLevel.Verbose,nameof(AletrisSandboxModule),h.Key + h.Value);
        }*/

        if (Level.EntityLoaders.TryGetValue(sid, out Level.EntityLoader loader))
        {
            Entity Actent = loader(scene,
                                   scene.Session.LevelData,
                                   stupidStoredOffset,
                new EntityData
                {
                    ID = 0,
                    Name = sid,
                    Level = scene.Session.LevelData,
                    Position = convertedPos,
                    Origin = new Vector2(0, 0), // not sure if this is actually it
                    Width = 0,
                    Height = 0,
                    Nodes = new Vector2[] { },
                    Values = convertedParams
                }); // ¯\_(ツ)_/¯
            ACMovement ac = new ACMovement();
            ac.Lifetime = lifeTimer;
            ac.velocity = convertedVel;
            ac.rebound = rebound;
            ac.followPlayerSpd = followPlayerSpd;

            Actent.Add(ac);
            Scene.Add(Actent);
            //Logger.Verbose(nameof(AletrisSandboxModule), "spawned " + sid + " at " + Actent.Position + " with velocity " + convertedVel);
        }
        else
        {
            Logger.Warn(nameof(AletrisSandboxModule),"Couldn't find entity loader for entity " + sid);
        }

    }

    public void FollowPlayer(Entity obj, int speed)
    {
        obj.Get<ACMovement>().followPlayerSpd = speed;
    } // ngl i dont know if this is needed

    public void DeleteObj(Entity obj)
    {
        obj.RemoveSelf();
    }

    private LuaTable CreateTable()
    {
        return (LuaTable)lua.DoString("return {}")[0];
    }

    public LuaTable AngleToCartesian(double angle, double magnitude)
    {
        double rad = angle * Math.PI / 180.0;
        double x = magnitude * Math.Cos(rad);
        double y = magnitude * Math.Sin(rad);
        lua.Push(x);
        lua.Push(y);
        // the new table is on top of the stack; get it as a LuaTable and pop it
        LuaTable tbl = CreateTable();
        tbl["x"] = x;
        tbl["y"] = y;
        return tbl;
    }
    #endregion

    public override void Awake(Scene scene)
    {
        string luaCode = Utils.ReadModAsset(luaData);

        lua.RegisterFunction("SpawnObj", this, GetType().GetMethod("SpawnObj"));
        lua.RegisterFunction(
            "AngleToCartesian",
            this,
            GetType().GetMethod("AngleToCartesian", new Type[] { typeof(double), typeof(double) }));

        Logger.Verbose(nameof(AletrisSandboxModule), "luaCode:" + luaCode);

        Logger.Verbose(nameof(AletrisSandboxModule),"running luaData as string!");
        try
        {
            lua.DoString(luaCode);
        } catch (Exception ex) {
            Logger.Verbose(nameof(AletrisSandboxModule), "Lua error: " + ex.Message);
            Logger.Verbose(nameof(AletrisSandboxModule), "Inner: " + ex.InnerException);
            Logger.Verbose(nameof(AletrisSandboxModule), ex.StackTrace);
        }
        base.Awake(scene);
    }

    public override void Update()
    {
        base.Update();

        try
        {
            var fn = lua["update"] as LuaFunction;
            if (fn == null)
            {
                Logger.Error(nameof(AletrisSandboxModule), "function update(t) does not exist");
            }
            fn!.Call(timer);
            timer += 1;
        } catch (Exception ex) {
            Logger.Error(nameof(AletrisSandboxModule), ex.Message);
            Logger.Verbose(nameof(AletrisSandboxModule), ex.StackTrace);
            Logger.Verbose(nameof(AletrisSandboxModule), ex.InnerException?.ToString());
        }
    }
}